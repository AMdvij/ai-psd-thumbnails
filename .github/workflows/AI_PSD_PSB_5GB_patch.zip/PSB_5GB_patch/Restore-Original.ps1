# Restore repository files from patch backups (does not change installed program).
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$dir = Join-Path $root 'crates\shell\src'
foreach ($name in @('lib.rs','thumbnail.rs','preview.rs')) {
    $file = Join-Path $dir $name
    $backup = $file + '.pre-psb5-backup'
    if (Test-Path $backup) { Copy-Item $backup $file -Force; Remove-Item $backup }
}
$newFile = Join-Path $dir 'fast_psb_stream.rs'
if (Test-Path $newFile) { Remove-Item $newFile }
Write-Host 'Original Rust source files restored.' -ForegroundColor Green
