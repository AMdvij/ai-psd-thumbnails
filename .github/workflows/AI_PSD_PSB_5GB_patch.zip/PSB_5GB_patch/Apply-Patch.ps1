# Apply next to the repository's Cargo.toml, from extracted PSB_5GB_patch folder.
# The original source files are backed up. No installed Windows DLL is changed.
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if (-not (Test-Path (Join-Path $root 'Cargo.toml'))) {
  throw "Cargo.toml not found beside PSB_5GB_patch. Extract patch folder inside the AI-PSD source root."
}
$dir = Join-Path $root 'crates\shell\src'
$libFile   = Join-Path $dir 'lib.rs'
$thumbFile = Join-Path $dir 'thumbnail.rs'
$prevFile  = Join-Path $dir 'preview.rs'
$newFile   = Join-Path $dir 'fast_psb_stream.rs'
$files = @($libFile, $thumbFile, $prevFile)
$utf8 = New-Object System.Text.UTF8Encoding($false)
foreach ($p in $files) { if (-not (Test-Path $p)) { throw "Source file missing: $p" } }
if (Test-Path $newFile) { throw 'fast_psb_stream.rs already exists. Patch may already be applied.' }
$lib = [IO.File]::ReadAllText($libFile)
$thumb = [IO.File]::ReadAllText($thumbFile)
$prev = [IO.File]::ReadAllText($prevFile)
if (-not $lib.Contains('pub(crate) mod stream_util;')) { throw 'Expected module line not found. Source may have changed.' }
foreach ($src in @($thumb, $prev)) {
  if (-not $src.Contains('use crate::stream_util::read_stream_all;')) { throw 'Expected import not found. Source may have changed.' }
  if (-not $src.Contains('let data = read_stream_all(stream)?;')) { throw 'Expected read call not found. Source may have changed.' }
}
$lib = $lib.Replace('pub(crate) mod stream_util;', "pub(crate) mod stream_util;`npub(crate) mod fast_psb_stream;")
$thumb = $thumb.Replace('use crate::stream_util::read_stream_all;', 'use crate::fast_psb_stream::read_stream_for_thumbnail;')
$thumb = $thumb.Replace('let data = read_stream_all(stream)?;', 'let data = read_stream_for_thumbnail(stream)?;')
$prev = $prev.Replace('use crate::stream_util::read_stream_all;', 'use crate::fast_psb_stream::read_stream_for_thumbnail;')
$prev = $prev.Replace('let data = read_stream_all(stream)?;', 'let data = read_stream_for_thumbnail(stream)?;')
foreach ($p in $files) {
  if (Test-Path ($p + '.pre-psb5-backup')) { throw "Backup already exists, stopping: $p" }
}
foreach ($p in $files) { Copy-Item $p ($p + '.pre-psb5-backup') }
try {
  [IO.File]::WriteAllText($libFile, $lib, $utf8)
  [IO.File]::WriteAllText($thumbFile, $thumb, $utf8)
  [IO.File]::WriteAllText($prevFile, $prev, $utf8)
  Copy-Item (Join-Path $PSScriptRoot 'fast_psb_stream.rs') $newFile
} catch {
  foreach ($p in $files) {
    if (Test-Path ($p + '.pre-psb5-backup')) { Copy-Item ($p + '.pre-psb5-backup') $p -Force }
  }
  if (Test-Path $newFile) { Remove-Item $newFile }
  throw
}
Write-Host 'Patch applied. Originals saved as *.pre-psb5-backup.' -ForegroundColor Green
Write-Host 'Now build the project using the README instructions. Windows installation is NOT changed yet.'
