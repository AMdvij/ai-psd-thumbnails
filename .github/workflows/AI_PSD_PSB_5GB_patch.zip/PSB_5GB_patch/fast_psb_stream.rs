//! Experimental bounded PSD/PSB thumbnail extraction for Explorer.
//!
//! Avoids buffering a multi-GB Photoshop document in the COM host.
//! Only reads the Photoshop Image Resources area and constructs a minimal
//! virtual PSD/PSB containing resource 1036 (or fallback 1033). The existing
//! ai_psd_thumbnails_core::psd decoder handles the resulting buffer.
//! If no embedded thumbnail is found, the original implementation remains
//! the fallback for files <= 2 GiB; larger files fail gracefully.

use windows::core::{Error, Result};
use windows::Win32::Foundation::E_FAIL;
use windows::Win32::System::Com::{IStream, STREAM_SEEK_END, STREAM_SEEK_SET};

const MAX_INPUT_BYTES: u64 = 5 * 1024 * 1024 * 1024; // 5 GiB user-defined cap
const MAX_EMBEDDED_BYTES: u64 = 16 * 1024 * 1024; // max single thumbnail resource
const MAX_RESOURCE_ENTRIES: usize = 65536;
const ORIGINAL_FALLBACK_CAP: u64 = 2 * 1024 * 1024 * 1024;

fn fail() -> Error { Error::from_hresult(E_FAIL) }

/// The shared entry point for the COM thumbnail and preview providers.
/// The caller will receive at most ~16 MiB for PSB files with JPEG thumbnail.
pub(crate) fn read_stream_for_thumbnail(stream: &IStream) -> Result<Vec<u8>> {
    // Explorer supplies a seekable file-backed IStream in the normal case.
    // Retain the upstream reader if the stream does not support seeking.
    let total_len = match stream_length(stream) {
        Ok(n) => n,
        Err(_) => return crate::stream_util::read_stream_all(stream),
    };
    if total_len > MAX_INPUT_BYTES {
        return Err(fail());
    }

    if let Ok(Some(preview)) = extract_virtual_psd(stream, total_len) {
        return Ok(preview);
    }

    // Do not read/clone several gigabytes just because no small resource exists.
    if total_len > ORIGINAL_FALLBACK_CAP {
        return Err(fail());
    }
    unsafe { stream.Seek(0, STREAM_SEEK_SET, None)?; }
    crate::stream_util::read_stream_all(stream)
}

fn stream_length(stream: &IStream) -> Result<u64> {
    let mut end = 0u64;
    unsafe {
        stream.Seek(0, STREAM_SEEK_END, Some(&mut end))?;
        stream.Seek(0, STREAM_SEEK_SET, None)?;
    }
    Ok(end)
}

fn read_at(stream: &IStream, pos: u64, dest: &mut [u8], total_len: u64) -> Result<()> {
    let end = pos.checked_add(dest.len() as u64).ok_or_else(fail)?;
    if end > total_len || pos > i64::MAX as u64 {
        return Err(fail());
    }
    unsafe { stream.Seek(pos as i64, STREAM_SEEK_SET, None)?; }
    let mut filled = 0usize;
    while filled < dest.len() {
        let requested = (dest.len() - filled).min(1024 * 1024) as u32;
        let mut got = 0u32;
        let hr = unsafe {
            stream.Read(
                dest[filled..].as_mut_ptr() as *mut std::ffi::c_void,
                requested,
                Some(&mut got),
            )
        };
        if hr.is_err() || got == 0 || got > requested {
            return Err(fail());
        }
        filled += got as usize;
    }
    Ok(())
}

fn u32_at(stream: &IStream, pos: u64, len: u64) -> Result<u32> {
    let mut b = [0u8; 4];
    read_at(stream, pos, &mut b, len)?;
    Ok(u32::from_be_bytes(b))
}

fn extract_virtual_psd(stream: &IStream, len: u64) -> Result<Option<Vec<u8>>> {
    if len < 34 { return Ok(None); }
    let mut header = [0u8; 26];
    read_at(stream, 0, &mut header, len)?;
    if &header[..4] != b"8BPS" || !matches!(header[5], 1 | 2) || header[4] != 0 {
        return Ok(None);
    }

    // Color Mode Data section: four-byte size even in PSB.
    let color_len = u32_at(stream, 26, len)? as u64;
    let resource_len_offset = 30u64.checked_add(color_len).ok_or_else(fail)?;
    let resources_len = u32_at(stream, resource_len_offset, len)? as u64;
    let start = resource_len_offset.checked_add(4).ok_or_else(fail)?;
    let end = start.checked_add(resources_len).ok_or_else(fail)?;
    if end > len { return Ok(None); }

    let mut pos = start;
    let mut legacy_thumbnail: Option<Vec<u8>> = None;
    for _ in 0..MAX_RESOURCE_ENTRIES {
        if pos == end { break; }
        if end - pos < 12 { break; }
        let mut resource_head = [0u8; 7]; // 8BIM(4), id(2), Pascal name length(1)
        read_at(stream, pos, &mut resource_head, len)?;
        if &resource_head[..4] != b"8BIM" { break; }
        let id = u16::from_be_bytes([resource_head[4], resource_head[5]]);
        let name_len = resource_head[6] as u64;
        let pascal_bytes = 1 + name_len;
        let padded_name_bytes = (pascal_bytes + 1) & !1;
        let size_pos = pos.checked_add(6 + padded_name_bytes).ok_or_else(fail)?;
        let data_len = u32_at(stream, size_pos, len)? as u64;
        let data_pos = size_pos.checked_add(4).ok_or_else(fail)?;
        let padded_data_len = data_len.checked_add(data_len & 1).ok_or_else(fail)?;
        let next = data_pos.checked_add(padded_data_len).ok_or_else(fail)?;
        if next > end { break; }

        if (id == 1036 || id == 1033) &&
            (28..=MAX_EMBEDDED_BYTES).contains(&data_len) {
            let mut resource = vec![0u8; data_len as usize];
            read_at(stream, data_pos, &mut resource, len)?;
            if id == 1036 {
                return Ok(Some(synthetic_psd(&header, 1036, &resource)));
            }
            if legacy_thumbnail.is_none() {
                legacy_thumbnail = Some(resource);
            }
        }
        pos = next;
    }

    Ok(legacy_thumbnail.map(|r| synthetic_psd(&header, 1033, &r)))
}

/// Minimal valid PSD/PSB wrapper: preserve the header, put the single thumbnail
/// resource in Image Resources; the decoder returns before reaching layer data.
fn synthetic_psd(header: &[u8; 26], resource_id: u16, resource_data: &[u8]) -> Vec<u8> {
    let padded_len = resource_data.len() + (resource_data.len() % 2);
    let section_len = 4 + 2 + 2 + 4 + padded_len;
    let mut output = Vec::with_capacity(26 + 4 + 4 + section_len);
    output.extend_from_slice(header);
    output.extend_from_slice(&0u32.to_be_bytes()); // empty Color Mode Data
    output.extend_from_slice(&(section_len as u32).to_be_bytes());
    output.extend_from_slice(b"8BIM");
    output.extend_from_slice(&resource_id.to_be_bytes());
    output.extend_from_slice(&[0u8; 2]); // zero-length Pascal name, padded
    output.extend_from_slice(&(resource_data.len() as u32).to_be_bytes());
    output.extend_from_slice(resource_data);
    if resource_data.len() % 2 != 0 { output.push(0); }
    output
}
